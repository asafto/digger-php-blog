-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2020 at 04:19 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digger`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `article` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `title`, `article`, `date`) VALUES
(2, 2, 'lsldkjvlsk', 'lskcjvlskvjls', '2020-09-24 15:25:43'),
(3, 1, 'lskdjclskdj', ',cm s mss', '2020-09-24 16:07:39'),
(15, 21, 'Asaf\'s first post', 'Yey!!!\r\nMy first post rocks', '2020-10-03 10:54:05'),
(16, 21, 'my new post', 'my updated article', '2020-10-04 13:46:19'),
(17, 21, 'kjkjhkj lkklj', 'kjhkjh hgjhg', '2020-10-04 16:41:09'),
(18, 22, 'This is demo user first post', 'Hey - welcome to digger blog. Signup and add your posts!', '2020-10-05 17:16:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `profile_image`) VALUES
(1, 'avi cohen', 'avi@gmail.com', '$2y$10$ci7Oqz6BYrdA3VeuPkbTt.vIjdeJOjAy6inm82C/8NdhNygs987x.', 'default-profile.png'),
(2, 'moshe levi', 'moshe@gmail.com', '$2y$10$ci7Oqz6BYrdA3VeuPkbTt.vIjdeJOjAy6inm82C/8NdhNygs987x.', 'default-profile.png'),
(21, 'Asaf Toledano', 'asafto@gmail.com', '$2y$10$CNZBQ6A/HEO5cSkKVaRo9uCYUath4vhknqUZGK6z3FPy9q8eL1IlO', '05.10.2020.09.11.15_66d2v_Asaf Toledano - light brown background small.png'),
(22, 'Demo user', 'demo@gmail.com', '$2y$10$fCLIyl5USbeQ6qyxNP.wgeLOmuAIm/0at2svMr97N1MEtzRlRn6sa', '05.10.2020.07.37.24_1SzEW_kdog-icon-bgc-white.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
